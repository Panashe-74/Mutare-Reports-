-- Mutare Reports: database setup.
-- Run this ONCE in Supabase: SQL Editor -> New query -> paste everything -> Run.

create table if not exists public.reports (
  id text primary key,
  category text not null,
  severity text not null check (severity in ('Low', 'Medium', 'High')),
  suburb text,
  description text,
  lat double precision not null,
  lng double precision not null,
  accuracy_m integer,
  photo_url text,
  status text not null default 'New'
    check (status in ('New', 'Assigned', 'In progress', 'Fixed')),
  assigned_to text,
  created_at timestamptz not null default now(),
  status_updated_at timestamptz,
  fixed_at timestamptz
);

alter table public.reports enable row level security;

grant usage on schema public to anon, authenticated;
grant select, insert on public.reports to anon;
grant select, insert, update, delete on public.reports to authenticated;

-- Anyone using the app can submit a new report (it must start as "New").
create policy "public can submit reports" on public.reports
  for insert to anon, authenticated
  with check (status = 'New');

-- Anyone can read reports (the map and dashboard view). Reports hold no personal details.
create policy "public can read reports" on public.reports
  for select to anon, authenticated
  using (true);

-- Only logged-in council staff can change or delete reports.
create policy "staff can update reports" on public.reports
  for update to authenticated
  using (true) with check (true);

create policy "staff can delete reports" on public.reports
  for delete to authenticated
  using (true);

-- Photo storage: a public bucket that the app can upload to.
insert into storage.buckets (id, name, public)
values ('report-photos', 'report-photos', true)
on conflict (id) do nothing;

create policy "public can upload report photos" on storage.objects
  for insert to anon, authenticated
  with check (bucket_id = 'report-photos');
